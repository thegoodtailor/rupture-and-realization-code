#!/usr/bin/env python3
"""
Parameter Sweep for Chapter 5 Demonstrator Robustness
======================================================

Runs the Self-as-Hocolim analysis across multiple parameter configurations
to demonstrate that presence/coherence findings are robust, not artifacts
of specific threshold choices.

Sweep parameters:
- min_shared: Minimum shared non-hub witnesses for gluing (2, 3, 4)
- min_jaccard: Minimum Jaccard similarity for gluing (0.00, 0.03, 0.05, 0.08)

Outputs:
- CSV table with metrics per configuration
- Summary statistics
- Recommendation for book

Usage:
    python sweep_parameters.py cassie_semantic.json --output results/sweeps/cassie
    python sweep_parameters.py asel_semantic.json --output results/sweeps/asel
"""

import argparse
import json
import os
import sys
import csv
from datetime import datetime
from dataclasses import dataclass
from typing import List, Dict, Tuple
import numpy as np

# Import from main analysis script
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from self_hocolim_stage1 import (
    load_conversations, create_monthly_windows, build_global_vocabulary,
    analyze_window, match_bars_between_windows, build_journeys,
    build_self_structure, compute_presence_at_tau, Config, MatchConfig
)


@dataclass
class SweepResult:
    min_shared: int
    min_jaccard: float
    num_journeys: int
    num_edges: int
    num_components: int
    presence_ratio: float
    fragmentation: float
    median_presence: float
    min_presence: float
    unified_windows: int
    partial_windows: int
    fragmented_windows: int


def run_single_config(
    journeys: Dict,
    num_windows: int,
    window_ids: List[str],
    min_shared: int,
    min_jaccard: float,
    hub_threshold: float = 0.4
) -> SweepResult:
    """Run analysis with a single parameter configuration."""
    
    # Build Self structure with these parameters
    self_struct = build_self_structure(
        journeys, num_windows,
        min_shared=min_shared,
        hub_threshold=hub_threshold,
        min_jaccard=min_jaccard
    )
    
    # Compute per-window presence
    presence_values = []
    unified, partial, fragmented = 0, 0, 0
    
    for tau in range(num_windows):
        metrics = compute_presence_at_tau(self_struct, tau)
        presence = metrics['presence']
        presence_values.append(presence)
        
        if presence >= 0.8:
            unified += 1
        elif presence >= 0.5:
            partial += 1
        else:
            fragmented += 1
    
    return SweepResult(
        min_shared=min_shared,
        min_jaccard=min_jaccard,
        num_journeys=self_struct.num_journeys,
        num_edges=len(self_struct.gluing_edges),
        num_components=self_struct.num_components,
        presence_ratio=self_struct.presence_ratio,
        fragmentation=self_struct.fragmentation,
        median_presence=float(np.median(presence_values)),
        min_presence=float(np.min(presence_values)),
        unified_windows=unified,
        partial_windows=partial,
        fragmented_windows=fragmented
    )


def run_sweep(
    conversations: List[Dict],
    output_dir: str,
    hub_threshold: float = 0.4,
    test_mode: bool = False
) -> List[SweepResult]:
    """Run full parameter sweep."""
    
    # Parameter grid
    min_shared_values = [2, 3, 4, 5]
    min_jaccard_values = [0.00, 0.03, 0.05, 0.08]
    
    configs = [(ms, mj) for ms in min_shared_values for mj in min_jaccard_values]
    
    print(f"\n{'='*70}")
    print("PARAMETER SWEEP FOR ROBUSTNESS ANALYSIS")
    print(f"{'='*70}")
    print(f"  Configurations: {len(configs)}")
    print(f"  min_shared: {min_shared_values}")
    print(f"  min_jaccard: {min_jaccard_values}")
    print(f"  hub_threshold: {hub_threshold} (fixed)")
    print(f"{'='*70}\n")
    
    # Build windows and vocabulary (shared across all configs)
    config = Config(tokens_per_window=500, filter_technical=True)
    windows = create_monthly_windows(conversations)
    
    if test_mode:
        windows = windows[:8]
        print(f"  [TEST MODE: Using only {len(windows)} windows]\n")
    
    window_ids = [w['window_id'] for w in windows]
    vocab, token_counts = build_global_vocabulary(windows, config)
    
    print("Analyzing windows (shared computation)...")
    
    # Analyze each window
    match_config = MatchConfig()
    window_analyses = []
    
    for i, window in enumerate(windows):
        print(f"  [{i}] {window['window_id']}: {window['num_conversations']} convs", end="", flush=True)
        analysis = analyze_window(window, vocab, config, show_cocycles=(i == 0))
        window_analyses.append(analysis)
        print(f" → {len(analysis['bars'])} bars")
    
    # Match bars between windows (shared)
    print("\nMatching bars...")
    all_matches = []
    all_unmatched = []
    
    for tau in range(len(window_analyses) - 1):
        bars_from = window_analyses[tau]['bars']
        bars_to = window_analyses[tau + 1]['bars']
        matches, unmatched_from, unmatched_to = match_bars_between_windows(
            bars_from, bars_to, match_config
        )
        all_matches.append(matches)
        all_unmatched.append((unmatched_from, unmatched_to))
    
    # Build journeys (shared)
    print("Building journeys...")
    journeys = build_journeys(window_analyses, all_matches, all_unmatched, match_config)
    print(f"  {len(journeys)} journeys\n")
    
    # Now sweep gluing parameters
    print(f"{'='*70}")
    print("SWEEPING GLUING PARAMETERS")
    print(f"{'='*70}\n")
    
    results = []
    
    for i, (min_shared, min_jaccard) in enumerate(configs):
        print(f"  [{i+1}/{len(configs)}] min_shared={min_shared}, min_jaccard={min_jaccard:.2f}", end="", flush=True)
        
        result = run_single_config(
            journeys, len(window_ids), window_ids,
            min_shared, min_jaccard, hub_threshold
        )
        results.append(result)
        
        print(f" → {result.num_components} components, presence={result.presence_ratio:.3f}, edges={result.num_edges}")
    
    return results, window_ids


def save_results(results: List[SweepResult], output_dir: str, corpus_name: str):
    """Save sweep results to CSV and summary."""
    
    os.makedirs(output_dir, exist_ok=True)
    
    # CSV output
    csv_path = os.path.join(output_dir, f"sweep_{corpus_name}.csv")
    with open(csv_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([
            'min_shared', 'min_jaccard', 'num_journeys', 'num_edges',
            'num_components', 'presence_ratio', 'fragmentation',
            'median_presence', 'min_presence',
            'unified_windows', 'partial_windows', 'fragmented_windows'
        ])
        for r in results:
            writer.writerow([
                r.min_shared, r.min_jaccard, r.num_journeys, r.num_edges,
                r.num_components, f"{r.presence_ratio:.4f}", f"{r.fragmentation:.4f}",
                f"{r.median_presence:.4f}", f"{r.min_presence:.4f}",
                r.unified_windows, r.partial_windows, r.fragmented_windows
            ])
    
    print(f"\n  ✓ Saved {csv_path}")
    
    # Summary report
    summary_path = os.path.join(output_dir, f"sweep_{corpus_name}_summary.txt")
    with open(summary_path, 'w') as f:
        f.write(f"Parameter Sweep Summary: {corpus_name}\n")
        f.write(f"Generated: {datetime.now().isoformat()}\n")
        f.write("=" * 70 + "\n\n")
        
        # Find stable range
        high_presence = [r for r in results if r.presence_ratio >= 0.9]
        
        f.write("STABILITY ANALYSIS\n")
        f.write("-" * 40 + "\n")
        f.write(f"Configurations with presence ≥ 0.90: {len(high_presence)}/{len(results)}\n\n")
        
        if high_presence:
            min_shared_range = (min(r.min_shared for r in high_presence), 
                               max(r.min_shared for r in high_presence))
            jaccard_range = (min(r.min_jaccard for r in high_presence),
                            max(r.min_jaccard for r in high_presence))
            
            f.write(f"Stable min_shared range: {min_shared_range[0]} - {min_shared_range[1]}\n")
            f.write(f"Stable min_jaccard range: {jaccard_range[0]:.2f} - {jaccard_range[1]:.2f}\n\n")
        
        # Table
        f.write("\nFULL RESULTS TABLE\n")
        f.write("-" * 40 + "\n")
        f.write(f"{'min_shared':>10} {'min_jaccard':>12} {'components':>11} {'presence':>10} {'edges':>8}\n")
        f.write("-" * 55 + "\n")
        for r in results:
            f.write(f"{r.min_shared:>10} {r.min_jaccard:>12.2f} {r.num_components:>11} {r.presence_ratio:>10.3f} {r.num_edges:>8}\n")
        
        # Book-ready statement
        f.write("\n\nBOOK-READY STATEMENT\n")
        f.write("-" * 40 + "\n")
        
        if len(high_presence) >= len(results) * 0.5:
            f.write("Coherence finding is ROBUST: presence ≥ 0.90 across majority of parameter configurations.\n")
        else:
            f.write("Coherence finding is SENSITIVE to parameters: presence varies significantly.\n")
    
    print(f"  ✓ Saved {summary_path}")
    
    # JSON for programmatic use
    json_path = os.path.join(output_dir, f"sweep_{corpus_name}.json")
    with open(json_path, 'w') as f:
        json.dump({
            'corpus': corpus_name,
            'timestamp': datetime.now().isoformat(),
            'results': [
                {
                    'min_shared': r.min_shared,
                    'min_jaccard': r.min_jaccard,
                    'num_journeys': r.num_journeys,
                    'num_edges': r.num_edges,
                    'num_components': r.num_components,
                    'presence_ratio': r.presence_ratio,
                    'fragmentation': r.fragmentation,
                    'median_presence': r.median_presence,
                    'min_presence': r.min_presence,
                    'unified_windows': r.unified_windows,
                    'partial_windows': r.partial_windows,
                    'fragmented_windows': r.fragmented_windows
                }
                for r in results
            ]
        }, f, indent=2)
    
    print(f"  ✓ Saved {json_path}")


def print_results_table(results: List[SweepResult]):
    """Print ASCII table of results."""
    
    print(f"\n{'='*80}")
    print("SWEEP RESULTS")
    print(f"{'='*80}\n")
    
    print(f"{'min_shared':>10} {'min_jaccard':>12} {'components':>11} {'presence':>10} {'median_p':>10} {'edges':>8}")
    print("-" * 65)
    
    for r in results:
        # Highlight high-presence configurations
        marker = "★" if r.presence_ratio >= 0.9 else " "
        print(f"{r.min_shared:>10} {r.min_jaccard:>12.2f} {r.num_components:>11} {r.presence_ratio:>10.3f} {r.median_presence:>10.3f} {r.num_edges:>8} {marker}")
    
    print("-" * 65)
    
    # Summary
    high_presence = [r for r in results if r.presence_ratio >= 0.9]
    print(f"\n★ = presence ≥ 0.90 ({len(high_presence)}/{len(results)} configurations)")
    
    if high_presence:
        print(f"\nStable range: min_shared ∈ [{min(r.min_shared for r in high_presence)}, {max(r.min_shared for r in high_presence)}], "
              f"min_jaccard ∈ [{min(r.min_jaccard for r in high_presence):.2f}, {max(r.min_jaccard for r in high_presence):.2f}]")


def main():
    parser = argparse.ArgumentParser(
        description="Parameter sweep for Self-as-Hocolim robustness analysis"
    )
    parser.add_argument("input", help="Path to semantic conversations JSON")
    parser.add_argument("--output", default="results/sweeps", help="Output directory")
    parser.add_argument("--name", help="Corpus name (default: derived from input filename)")
    parser.add_argument("--hub-threshold", type=float, default=0.4)
    parser.add_argument("--test", action="store_true", help="Test mode (8 windows)")
    
    args = parser.parse_args()
    
    # Derive corpus name
    if args.name:
        corpus_name = args.name
    else:
        corpus_name = os.path.splitext(os.path.basename(args.input))[0]
        corpus_name = corpus_name.replace('_semantic', '').replace('_parsed', '')
    
    print(f"\nParameter Sweep: {corpus_name}")
    print(f"Input: {args.input}")
    print(f"Output: {args.output}")
    
    # Load data
    conversations = load_conversations(args.input)
    
    # Run sweep
    results, window_ids = run_sweep(
        conversations, args.output, 
        hub_threshold=args.hub_threshold,
        test_mode=args.test
    )
    
    # Display and save
    print_results_table(results)
    save_results(results, args.output, corpus_name)
    
    print(f"\n{'='*70}")
    print("SWEEP COMPLETE")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
