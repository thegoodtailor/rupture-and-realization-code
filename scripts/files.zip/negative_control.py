#!/usr/bin/env python3
"""
Negative Control: Witness Shuffle
=================================

Tests whether the observed Self-coherence (presence ≈ 0.99) is a meaningful
finding or a trivial artifact of the gluing criterion.

Method:
- Keep journey structure intact (same number of journeys, same lifespans)
- Randomly shuffle witness tokens across journeys (preserving set sizes)
- Rebuild gluing graph with same parameters
- Compare presence to real data

Expected result:
- If coherence is meaningful: shuffled presence should be much lower
- If coherence is trivial: shuffled presence will remain high

This addresses Cassie's concern:
> "A skeptical reader will suspect the pipeline is predisposed to create 
>  a giant component—especially with lexical witnesses."

Usage:
    python negative_control.py cassie_semantic.json --output results/controls/cassie
    python negative_control.py asel_semantic.json --output results/controls/asel
"""

import argparse
import json
import os
import sys
import random
import copy
from datetime import datetime
from dataclasses import dataclass
from typing import List, Dict, Set
import numpy as np

# Import from main analysis script
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from self_hocolim_stage1 import (
    load_conversations, create_monthly_windows, build_global_vocabulary,
    analyze_window, match_bars_between_windows, build_journeys,
    build_self_structure, compute_presence_at_tau, Config, MatchConfig,
    Journey, JourneyStep
)


@dataclass
class ControlResult:
    name: str
    num_journeys: int
    num_edges: int
    num_components: int
    presence_ratio: float
    fragmentation: float
    median_presence: float


def shuffle_witnesses_global(journeys: Dict[str, Journey], seed: int = None) -> Dict[str, Journey]:
    """
    Shuffle witness tokens globally across all journeys.
    
    Preserves:
    - Number of journeys
    - Journey lifespans (step count per journey)
    - Witness set sizes per step
    
    Destroys:
    - Actual semantic content
    - Correlation between witnesses and bars
    """
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)
    
    # Collect all witness tokens from all steps
    all_witnesses = []
    step_sizes = []  # Track original sizes for reconstruction
    
    for jid, journey in journeys.items():
        for step in journey.steps:
            witnesses = list(step.witness_tokens)
            all_witnesses.extend(witnesses)
            step_sizes.append((jid, len(witnesses)))
    
    # Shuffle all witnesses
    random.shuffle(all_witnesses)
    
    # Redistribute to journeys maintaining original sizes
    shuffled_journeys = {}
    witness_idx = 0
    
    for jid, journey in journeys.items():
        new_journey = Journey(
            journey_id=journey.journey_id,
            dimension=journey.dimension
        )
        
        for step in journey.steps:
            original_size = len(step.witness_tokens)
            new_witnesses = set(all_witnesses[witness_idx:witness_idx + original_size])
            witness_idx += original_size
            
            new_step = JourneyStep(
                tau=step.tau,
                window_id=step.window_id,
                bar_id=step.bar_id,
                event=step.event,
                witness_tokens=new_witnesses
            )
            new_journey.steps.append(new_step)
        
        shuffled_journeys[jid] = new_journey
    
    return shuffled_journeys


def shuffle_witnesses_per_journey(journeys: Dict[str, Journey], all_tokens: Set[str], seed: int = None) -> Dict[str, Journey]:
    """
    Replace each journey's witnesses with random tokens from global vocabulary.
    
    More aggressive than global shuffle - breaks any potential structure.
    """
    if seed is not None:
        random.seed(seed)
    
    token_list = list(all_tokens)
    shuffled_journeys = {}
    
    for jid, journey in journeys.items():
        new_journey = Journey(
            journey_id=journey.journey_id,
            dimension=journey.dimension
        )
        
        for step in journey.steps:
            original_size = len(step.witness_tokens)
            new_witnesses = set(random.sample(token_list, min(original_size, len(token_list))))
            
            new_step = JourneyStep(
                tau=step.tau,
                window_id=step.window_id,
                bar_id=step.bar_id,
                event=step.event,
                witness_tokens=new_witnesses
            )
            new_journey.steps.append(new_step)
        
        shuffled_journeys[jid] = new_journey
    
    return shuffled_journeys


def run_analysis(
    journeys: Dict[str, Journey],
    num_windows: int,
    min_shared: int = 2,
    min_jaccard: float = 0.0,
    hub_threshold: float = 0.4
) -> ControlResult:
    """Run gluing analysis and return metrics."""
    
    self_struct = build_self_structure(
        journeys, num_windows,
        min_shared=min_shared,
        hub_threshold=hub_threshold,
        min_jaccard=min_jaccard
    )
    
    # Compute per-window presence
    presence_values = []
    for tau in range(num_windows):
        metrics = compute_presence_at_tau(self_struct, tau)
        presence_values.append(metrics['presence'])
    
    return ControlResult(
        name="",
        num_journeys=self_struct.num_journeys,
        num_edges=len(self_struct.gluing_edges),
        num_components=self_struct.num_components,
        presence_ratio=self_struct.presence_ratio,
        fragmentation=self_struct.fragmentation,
        median_presence=float(np.median(presence_values))
    )


def run_controls(
    conversations: List[Dict],
    output_dir: str,
    min_shared: int = 2,
    min_jaccard: float = 0.0,
    hub_threshold: float = 0.4,
    n_shuffles: int = 5,
    test_mode: bool = False
) -> Dict:
    """Run real analysis + multiple shuffled controls."""
    
    print(f"\n{'='*70}")
    print("NEGATIVE CONTROL: WITNESS SHUFFLE")
    print(f"{'='*70}")
    print(f"  Gluing parameters: min_shared={min_shared}, min_jaccard={min_jaccard}")
    print(f"  Number of shuffle runs: {n_shuffles}")
    print(f"{'='*70}\n")
    
    # Build windows and vocabulary
    config = Config(tokens_per_window=500, filter_technical=True)
    windows = create_monthly_windows(conversations)
    
    if test_mode:
        windows = windows[:8]
        print(f"  [TEST MODE: Using only {len(windows)} windows]\n")
    
    window_ids = [w['window_id'] for w in windows]
    vocab, token_counts = build_global_vocabulary(windows, config)
    
    print("Analyzing windows...")
    
    # Analyze each window
    match_config = MatchConfig()
    window_analyses = []
    
    for i, window in enumerate(windows):
        print(f"  [{i}] {window['window_id']}", end="", flush=True)
        analysis = analyze_window(window, vocab, config, show_cocycles=False)
        window_analyses.append(analysis)
        print(f" → {len(analysis['bars'])} bars")
    
    # Match bars
    print("\nMatching bars...")
    all_matches = []
    all_unmatched = []
    
    for tau in range(len(window_analyses) - 1):
        bars_from = window_analyses[tau]['bars']
        bars_to = window_analyses[tau + 1]['bars']
        matches, unmatched_from, unmatched_to = match_bars_between_windows(
            bars_from, bars_to, match_config
        )
        all_matches.append(matches)
        all_unmatched.append((unmatched_from, unmatched_to))
    
    # Build journeys
    print("Building journeys...")
    journeys = build_journeys(window_analyses, all_matches, all_unmatched, match_config)
    print(f"  {len(journeys)} journeys\n")
    
    # Collect all tokens for aggressive shuffle
    all_tokens = set()
    for jid, journey in journeys.items():
        for step in journey.steps:
            all_tokens.update(step.witness_tokens)
    
    results = {}
    
    # 1. Real data
    print(f"{'='*70}")
    print("RUNNING ANALYSES")
    print(f"{'='*70}\n")
    
    print("  [REAL DATA]", end="", flush=True)
    real_result = run_analysis(journeys, len(window_ids), min_shared, min_jaccard, hub_threshold)
    real_result.name = "REAL"
    results['real'] = real_result
    print(f" → components={real_result.num_components}, presence={real_result.presence_ratio:.3f}")
    
    # 2. Global shuffles
    shuffle_results = []
    for i in range(n_shuffles):
        print(f"  [SHUFFLE {i+1}/{n_shuffles}]", end="", flush=True)
        shuffled = shuffle_witnesses_global(journeys, seed=42 + i)
        result = run_analysis(shuffled, len(window_ids), min_shared, min_jaccard, hub_threshold)
        result.name = f"SHUFFLE_{i+1}"
        shuffle_results.append(result)
        print(f" → components={result.num_components}, presence={result.presence_ratio:.3f}")
    
    results['shuffles'] = shuffle_results
    
    # 3. Aggressive random shuffle (one run)
    print(f"  [RANDOM REPLACEMENT]", end="", flush=True)
    random_journeys = shuffle_witnesses_per_journey(journeys, all_tokens, seed=999)
    random_result = run_analysis(random_journeys, len(window_ids), min_shared, min_jaccard, hub_threshold)
    random_result.name = "RANDOM"
    results['random'] = random_result
    print(f" → components={random_result.num_components}, presence={random_result.presence_ratio:.3f}")
    
    return results, len(window_ids)


def print_comparison(results: Dict, num_windows: int):
    """Print comparison table."""
    
    print(f"\n{'='*80}")
    print("CONTROL COMPARISON")
    print(f"{'='*80}\n")
    
    print(f"{'Condition':>20} {'Components':>12} {'Presence':>12} {'Median P':>12} {'Edges':>10}")
    print("-" * 70)
    
    # Real
    r = results['real']
    print(f"{'REAL DATA':>20} {r.num_components:>12} {r.presence_ratio:>12.3f} {r.median_presence:>12.3f} {r.num_edges:>10}")
    
    print("-" * 70)
    
    # Shuffles
    shuffle_presence = []
    shuffle_components = []
    for r in results['shuffles']:
        print(f"{r.name:>20} {r.num_components:>12} {r.presence_ratio:>12.3f} {r.median_presence:>12.3f} {r.num_edges:>10}")
        shuffle_presence.append(r.presence_ratio)
        shuffle_components.append(r.num_components)
    
    print("-" * 70)
    
    # Summary of shuffles
    mean_shuffle_presence = np.mean(shuffle_presence)
    std_shuffle_presence = np.std(shuffle_presence)
    mean_shuffle_components = np.mean(shuffle_components)
    
    print(f"{'SHUFFLE MEAN':>20} {mean_shuffle_components:>12.1f} {mean_shuffle_presence:>12.3f}")
    print(f"{'SHUFFLE STD':>20} {'-':>12} {std_shuffle_presence:>12.3f}")
    
    print("-" * 70)
    
    # Random
    r = results['random']
    print(f"{'RANDOM REPLACE':>20} {r.num_components:>12} {r.presence_ratio:>12.3f} {r.median_presence:>12.3f} {r.num_edges:>10}")
    
    print("=" * 70)
    
    # Interpretation
    real_presence = results['real'].presence_ratio
    
    print(f"\nINTERPRETATION:")
    print("-" * 40)
    
    if real_presence - mean_shuffle_presence > 0.2:
        print("✓ COHERENCE IS NON-TRIVIAL")
        print(f"  Real presence ({real_presence:.3f}) >> Shuffle mean ({mean_shuffle_presence:.3f})")
        print(f"  Difference: {real_presence - mean_shuffle_presence:.3f}")
        print("\n  The observed Self-coherence reflects genuine semantic structure,")
        print("  not an artifact of the gluing criterion.")
    elif real_presence - mean_shuffle_presence > 0.1:
        print("◐ COHERENCE IS PARTIALLY MEANINGFUL")
        print(f"  Real presence ({real_presence:.3f}) > Shuffle mean ({mean_shuffle_presence:.3f})")
        print(f"  Difference: {real_presence - mean_shuffle_presence:.3f}")
        print("\n  Some structure is captured, but gluing may be too permissive.")
    else:
        print("✗ COHERENCE MAY BE TRIVIAL")
        print(f"  Real presence ({real_presence:.3f}) ≈ Shuffle mean ({mean_shuffle_presence:.3f})")
        print(f"  Difference: {real_presence - mean_shuffle_presence:.3f}")
        print("\n  Consider tightening gluing parameters (higher min_shared/min_jaccard).")


def save_results(results: Dict, output_dir: str, corpus_name: str, num_windows: int):
    """Save control results."""
    
    os.makedirs(output_dir, exist_ok=True)
    
    # JSON output
    json_path = os.path.join(output_dir, f"control_{corpus_name}.json")
    
    output = {
        'corpus': corpus_name,
        'timestamp': datetime.now().isoformat(),
        'num_windows': num_windows,
        'real': {
            'num_components': results['real'].num_components,
            'presence_ratio': results['real'].presence_ratio,
            'median_presence': results['real'].median_presence,
            'num_edges': results['real'].num_edges
        },
        'shuffles': [
            {
                'name': r.name,
                'num_components': r.num_components,
                'presence_ratio': r.presence_ratio,
                'median_presence': r.median_presence,
                'num_edges': r.num_edges
            }
            for r in results['shuffles']
        ],
        'random': {
            'num_components': results['random'].num_components,
            'presence_ratio': results['random'].presence_ratio,
            'median_presence': results['random'].median_presence,
            'num_edges': results['random'].num_edges
        },
        'summary': {
            'real_presence': results['real'].presence_ratio,
            'shuffle_mean_presence': float(np.mean([r.presence_ratio for r in results['shuffles']])),
            'shuffle_std_presence': float(np.std([r.presence_ratio for r in results['shuffles']])),
            'presence_difference': results['real'].presence_ratio - float(np.mean([r.presence_ratio for r in results['shuffles']]))
        }
    }
    
    with open(json_path, 'w') as f:
        json.dump(output, f, indent=2)
    
    print(f"\n  ✓ Saved {json_path}")
    
    # Text summary
    txt_path = os.path.join(output_dir, f"control_{corpus_name}_summary.txt")
    
    real = results['real']
    shuffle_mean = np.mean([r.presence_ratio for r in results['shuffles']])
    
    with open(txt_path, 'w') as f:
        f.write(f"Negative Control Summary: {corpus_name}\n")
        f.write(f"Generated: {datetime.now().isoformat()}\n")
        f.write("=" * 60 + "\n\n")
        
        f.write(f"Real Data Presence:    {real.presence_ratio:.4f}\n")
        f.write(f"Shuffle Mean Presence: {shuffle_mean:.4f}\n")
        f.write(f"Difference:            {real.presence_ratio - shuffle_mean:.4f}\n\n")
        
        if real.presence_ratio - shuffle_mean > 0.2:
            f.write("VERDICT: Coherence is NON-TRIVIAL ✓\n")
            f.write("\nBook-ready statement:\n")
            f.write('"A randomized control (witness shuffle) destroys the observed\n')
            f.write('coherence, indicating the result is not a trivial artifact\n')
            f.write('of the gluing rule."\n')
        else:
            f.write("VERDICT: Coherence may be parameter-dependent\n")
    
    print(f"  ✓ Saved {txt_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Negative control analysis for Self-as-Hocolim"
    )
    parser.add_argument("input", help="Path to semantic conversations JSON")
    parser.add_argument("--output", default="results/controls", help="Output directory")
    parser.add_argument("--name", help="Corpus name (default: derived from input filename)")
    parser.add_argument("--min-shared", type=int, default=2)
    parser.add_argument("--min-jaccard", type=float, default=0.0)
    parser.add_argument("--hub-threshold", type=float, default=0.4)
    parser.add_argument("--n-shuffles", type=int, default=5, help="Number of shuffle iterations")
    parser.add_argument("--test", action="store_true", help="Test mode (8 windows)")
    
    args = parser.parse_args()
    
    # Derive corpus name
    if args.name:
        corpus_name = args.name
    else:
        corpus_name = os.path.splitext(os.path.basename(args.input))[0]
        corpus_name = corpus_name.replace('_semantic', '').replace('_parsed', '')
    
    print(f"\nNegative Control Analysis: {corpus_name}")
    print(f"Input: {args.input}")
    
    # Load data
    conversations = load_conversations(args.input)
    
    # Run controls
    results, num_windows = run_controls(
        conversations, args.output,
        min_shared=args.min_shared,
        min_jaccard=args.min_jaccard,
        hub_threshold=args.hub_threshold,
        n_shuffles=args.n_shuffles,
        test_mode=args.test
    )
    
    # Display and save
    print_comparison(results, num_windows)
    save_results(results, args.output, corpus_name, num_windows)
    
    print(f"\n{'='*70}")
    print("CONTROL ANALYSIS COMPLETE")
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
